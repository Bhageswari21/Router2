import ACTION_TYPES from '../actions/actionTypes';
import  valuesReducers  from './valuesReducer';
const INITIAL_STATE = {
    result: [],
    error: null
}
describe('testing reducer', () => {
    it('returns the initial state', () => {
        expect(valuesReducers(undefined, {})).toEqual(INITIAL_STATE);
    });
    it('handles success', () => {
        expect(valuesReducers(INITIAL_STATE, {
            type: ACTION_TYPES.FETCH_SUCCESS ,
            payload:['Blaze'],
        })).toEqual({
            ...INITIAL_STATE,
            result: ['Blaze']
        });
    });

    it('handles error', () => {
        expect(valuesReducers(INITIAL_STATE, {
            type: ACTION_TYPES.FETCH_FAIL,
            payload: "undefined"
        })).toEqual({
            ...INITIAL_STATE,
            error: "undefined"
        });
    });
});
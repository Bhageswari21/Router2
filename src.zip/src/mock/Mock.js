const Demo = {
    
    heading:"ToDo App",
    enter:"Please enter your Task",
    addButtonText:"Add",
    editButtonText:"Edit",
    deleteButtonText:"Delete",
    popupCancel:"Cancel",
    popupSave:"Save",
    popupHeading:"Let's make some changes"
}
export default Demo;
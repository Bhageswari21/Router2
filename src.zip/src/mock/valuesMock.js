
const Data = 
{
  heading: "Pokemon API",
  drop1:
  [
    {
      "ability":
      {     
        "name": "charmeleon",    
      }
    },
     
    {
      "ability": 
      {
        "name": "bulbasaur",
      }
    },
     
    {    
      "ability": 
      {     
        "name": "squirtle",         
      }
    },
     
    {     
      "ability": 
      { 
        "name": "weedle",
      }
    }
   
  ],
    
}
export default Data;